## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(VedicDateTime)
library(VedicDateTimedummy)

## -----------------------------------------------------------------------------
Ghatis(time_hours=41)
Muhurta(time_mins=200)
Purna_Tithi(jd=2460030,place=c(22.80, 86.20, +5.5))
Ritika_Tithi(jd=2460030,place=c(22.80, 86.20, +5.5))
Sun_time(jd=2460030,place=c(22.80, 86.20, +5.5))

