#' Check for Purna Tithi
#'
#' @param jd The Julian day number
#' @param place The latitude,longitude and timezone of the location
#'
#' @return A statement confirming if the tithi is a Purna Tithi
#' @export
#'
#' @examples Purna_Tithi()
#' @importFrom VedicDateTime tithi
Purna_Tithi<-function(jd=2460030,place=c(22.80, 86.20, +5.5))
  {
  tithi<-tithi(jd,place)
  if(tithi[1]%%5==0 || tithi[1]!=30)#A tithi is considered Purna(complete or auspicious) if it is
    #Day 5 (Panchami), 10 (Dashmi), and Purnima or Full Moon Day of both the Shukla and Krishna Paksha.
  {
    cat(paste0("The Tithi is a Purna Tithi"))
  }
  else
  {
    cat(paste0("The Tithi is not a Purna Tithi"))
  }
  }
