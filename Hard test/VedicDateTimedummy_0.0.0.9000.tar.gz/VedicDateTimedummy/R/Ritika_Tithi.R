#' Check for Ritika Tithi
#'
#' @param jd The Julian day number
#' @param place The latitude,longitude and timezone of the location
#'
#' @return A statement confirming if the tithi is a Ritika Tithi
#' @export
#'
#' @examples Ritika_Tithi()
#' @importFrom VedicDateTime tithi
Ritika_Tithi<-function(jd=2460030,place=c(22.80, 86.20, +5.5))
  {
  tithi<-tithi(jd=2460036,place=c(22.80, 86.20, +5.5))
  if((tithi[1]%%5+1)==0 && tithi[1]==30)#A titihi is considered Ritika if it is
  #Day 4 (Chaturthi), Day 9 (Navmi), Day 14 (Chaturdashi), and Amavasya of both Krishna and Shukla Paksha
  {
    cat(paste0("The Tithi is a Ritika Tithi"))
  }
  else
  {
    cat(paste0("The Tithi is not a Ritika Tithi"))
  }
  }
