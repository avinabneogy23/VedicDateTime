#' Convert time into Vedic units
#'
#' @param time_mins The input time is in minutes
#'
#' @return The time in minutes converted into Vedic units of time muhurta,kaala,kaastha and nimesha
#' @export
#'
#' @examples Muhurta()
#' @examples Muhurta(140)
#' @examples Muhurta(time_mins=200)
Muhurta<-function(time_mins=230){
  time_hours<-time_mins/60
  time_muhurta<-time_hours*1.25
  time_kaala<-time_muhurta*30
  time_kaastha<-time_kaala*30
  time_nimesha<-time_kaastha*18
  cat(paste0(time_mins,"Minutes is equivalent to ",time_muhurta,"Muhurtas"))
  cat(paste0(time_mins,"Minutes is equivalent to ",time_kaala,"Kaalas"))
  cat(paste0(time_mins,"Minutes is equivalent to ",time_kaastha,"Kaasthas"))
  cat(paste0(time_mins,"Minutes is equivalent to ",time_nimesha,"Nimeshas"))
}
