#' Get time in Ghatis and Vighatis from time in hours
#'
#' @param time_hours Time in hours which is to be converted
#'
#' @return The time in Ghatis and Vighatis
#' @export
#'
#' @examples Ghatis()
#' @examples Ghatis(32)
#' @examples Ghatis(time_hours=41)
Ghatis<-function(time_hours=29)
  {
  time_ghati<-time_hours*2.5#Converts time in hours to time in Ghati
  if(time_ghati%%1==0)#checks if the time in ghati is a whole number
  {
    cat(paste0("Equivalent time is ",time_ghati," Ghatis"))
  }
  else
  {
    frac<-time_ghati%%1#Calculates the fractional part of the time in Ghati converts it into minutes and then into vighati
    rem<-time_ghati-frac
    time_h<-0.4*frac
    time_min<-time_h*60
    time_vighati<-time_min*2.5
    cat(paste0("Equivalent time is ",rem," Ghatis and ",time_vighati," Vighatis"))
  }
  }
