#' Get the time for which the sun is up
#'
#' @param jd The Julian day number
#' @param place The latitute,longitude and timezone of the location
#'
#' @return The time for which the Sun is up in the sky
#' @export
#'
#' @examples Sun_time()
#' @examples Sun_time(2460036,c(22.80, 86.20, +5.5))
#' @examples Sun_time(jd=2460030,place=c(22.80, 86.20, +5.5))
#' @importFrom VedicDateTime sunrise
#' @importFrom VedicDateTime sunset
Sun_time<-function(jd=2460036,place=c(22.80, 86.20, +5.5))
  {
  sunrise<-sunrise(jd, place)#Calculates the time of sunrise
  sunset<-sunset(jd,place)#Calculates the time of sunset
  time<-sunrise-sunset
  abs(time)#Takes the absolute difference of the two times
  cat(paste0("The time for which the sun is up is ",abs(time[2])," hours,"
        ,abs(time[3])," minutes and ",abs(time[4])," seconds"))
  }

